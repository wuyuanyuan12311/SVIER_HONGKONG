clc;
close all;
clear all; 
beta1=0.6913; 
beta2=0.9947;
%beta2=1.2649;
gama1=0.3481;
gama2=0.1108;
dert=0.0307;
rou1=0.3271;
rou2=0.0913;
rou3=0.0572;
mui=0.0315;
k=1/3;
p1=0;
p2_1=0;%(未接种)
p2_2=0.032;%(3月中旬接种)
p2_2=0.037;%(4月中旬接种)
p2_2=0.051;%(5月中旬接种)

A=800;%
%N=20000;%(由于考虑了因病死亡，所以总人数N应为变量)
dt=0.01;%步长
da=0.01;
%h=step; 
p=1;
T=800;%(以天为单位)
nt=T/dt;%
na=A/da;%
S=zeros(nt,1);
E1=zeros(nt,1);
E2=zeros(nt,1);
E3=zeros(nt,1);
I1=zeros(nt,1);
I2=zeros(nt,1);
R=zeros(nt,1);
D=zeros(nt,1);
N=zeros(nt,1);
V1=zeros(nt,na);
V2=zeros(nt,na);
%%%%%%%%%%%%%%%%%%%
S_2=zeros(nt,1);
E1_2=zeros(nt,1);
E2_2=zeros(nt,1);
E3_2=zeros(nt,1);
I1_2=zeros(nt,1);
I2_2=zeros(nt,1);
R_2=zeros(nt,1);
D_2=zeros(nt,1);
N_2=zeros(nt,1);
V1_2=zeros(nt,na);
V2_2=zeros(nt,na);
%%%%%%%%%%%%%%%%%%%
S_3=zeros(nt,1);
E1_3=zeros(nt,1);
E2_3=zeros(nt,1);
E3_3=zeros(nt,1);
I1_3=zeros(nt,1);
I2_3=zeros(nt,1);
R_3=zeros(nt,1);
D_3=zeros(nt,1);
N_3=zeros(nt,1);
V1_3=zeros(nt,na);
V2_3=zeros(nt,na);
%%%%%%%%%%%%%%%%%%%
S_4=zeros(nt,1);
E1_4=zeros(nt,1);
E2_4=zeros(nt,1);
E3_4=zeros(nt,1);
I1_4=zeros(nt,1);
I2_4=zeros(nt,1);
R_4=zeros(nt,1);
D_4=zeros(nt,1);
N_4=zeros(nt,1);
V1_4=zeros(nt,na);
V2_4=zeros(nt,na);
%%%%%%%%%%%%%%%%%%%%%%
S0=283700000;
V10=1701000;
V20=597600000;
E10=5600;
E20=1114;
E30=302600;
R0=742000;
I10=212000;
I20=36000;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ;
%D0=0;
%e10=0;e20=0;
S(1)=S0;
E1(1)=E10;
E2(1)=E20;
E3(1)=E30;
I1(1)=I10;
I2(1)=I20;
R(1)=R0;
D(1)=D0;
V1(1,1)=V10;
V2(1,1)=V20;
%%%%%%%%%%%%%%%%
S_2(1)=S0;
E1_2(1)=E10;
E2_2(1)=E20;
E3_2(1)=E30;
I1_2(1)=I10;
I2_2(1)=I20;
R_2(1)=R0;
D_2(1)=D0;
V1_2(1,1)=V10;
V2_2(1,1)=V20;
%%%%%%%%%%%%%%%%
S_3(1)=S0;
E1_3(1)=E10;
E2_3(1)=E20;
E3_3(1)=E30;
I1_3(1)=I10;
I2_3(1)=I20;
R_3(1)=R0;
D_3(1)=D0;
V1_3(1,1)=V10;
V2_3(1,1)=V20;
%%%%%%%%%%%%%%%%
S_4(1)=S0;
E1_4(1)=E10;
E2_4(1)=E20;
E3_4(1)=E30;
I1_4(1)=I10;
I2_4(1)=I20;
R_4(1)=R0;
D_4(1)=D0;
V1_4(1,1)=V10;
V2_4(1,1)=V20;

for t=1:1:nt-1
    X1(t)=sum(V1(t,:));
    X2(t)=sum(V2(t,:));
    %%%%%%%%%%%%%%%%%%%
    X1_2(t)=sum(V1_2(t,:));
    X2_2(t)=sum(V2_2(t,:));
    %%%%%%%%%%%%%%%%%%%
    X1_3(t)=sum(V1_3(t,:));
    X2_3(t)=sum(V2_3(t,:));
    %%%%%%%%%%%%%%%%%%%
    X1_4(t)=sum(V1_4(t,:));
    X2_4(t)=sum(V2_4(t,:));
    %%%%%%%%%%%%%%%%%%%
    N(1)=S(1)+X1(1)+X2(1)+E1(1)+E2(1)+E3(1)+I1(1)+I2(1)+R(1);
    %%%%%%%%%%%%%%%%%%%
    N_2(1)=S_2(1)+X1_2(1)+X2_2(1)+E1_2(1)+E2_2(1)+E3_2(1)+I1_2(1)+I2_2(1)+R_2(1);
    %%%%%%%%%%%%%%%%%%%
    N_3(1)=S_3(1)+X1_3(1)+X2_3(1)+E1_3(1)+E2_3(1)+E3_3(1)+I1_3(1)+I2_3(1)+R_3(1);
    %%%%%%%%%%%%%%%%%%%
    N_4(1)=S_4(1)+X1_4(1)+X2_4(1)+E1_4(1)+E2_4(1)+E3_4(1)+I1_4(1)+I2_4(1)+R_4(1);
    
    for a=1:1:na-1

        %q(t,a)=(p2((a-1)*da)*V1(t,a)+p2((a-1)*da)*V1(t,a+1))*da/2;
        q(t,a)=(p2_1*V1(t,a)+p2_1*V1(t,a+1))*da/2;
        m1(t,a)=(beta1*(1-lmda1((a-1)*da))*V1(t,a)+beta1*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m2(t,a)=(beta2*(1-lmda1((a-1)*da))*V1(t,a)+beta2*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m3(t,a)=(beta1*(1-lmda2((a-1)*da))*V2(t,a)+beta1*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
        m4(t,a)=(beta2*(1-lmda2((a-1)*da))*V2(t,a)+beta2*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
        n1(t,a)=((lmda1((a-1)*da))*V1(t,a)+(lmda1((a)*da))*V1(t,a+1))*da/2;
        n2(t,a)=((lmda2((a-1)*da))*V2(t,a)+(lmda2((a)*da))*V2(t,a+1))*da/2;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        q2(t,a)=(p2_2*V1_2(t,a)+p2_2*V1_2(t,a+1))*da/2;
        m1_2(t,a)=(beta1*(1-lmda1((a-1)*da))*V1_2(t,a)+beta1*(1-lmda1((a)*da))*V1_2(t,a+1))*da/2;
        m2_2(t,a)=(beta2*(1-lmda1((a-1)*da))*V1_2(t,a)+beta2*(1-lmda1((a)*da))*V1_2(t,a+1))*da/2;
        m3_2(t,a)=(beta1*(1-lmda2((a-1)*da))*V2_2(t,a)+beta1*(1-lmda2((a)*da))*V2_2(t,a+1))*da/2;
        m4_2(t,a)=(beta2*(1-lmda2((a-1)*da))*V2_2(t,a)+beta2*(1-lmda2((a)*da))*V2_2(t,a+1))*da/2;
        n1_2(t,a)=((lmda1((a-1)*da))*V1_2(t,a)+(lmda1((a)*da))*V1_2(t,a+1))*da/2;
        n2_2(t,a)=((lmda2((a-1)*da))*V2_2(t,a)+(lmda2((a)*da))*V2_2(t,a+1))*da/2;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        q3(t,a)=(p2_3*V1_3(t,a)+p2_3*V1_3(t,a+1))*da/2;
        m1_3(t,a)=(beta1*(1-lmda1((a-1)*da))*V1_3(t,a)+beta1*(1-lmda1((a)*da))*V1_3(t,a+1))*da/2;
        m2_3(t,a)=(beta2*(1-lmda1((a-1)*da))*V1_3(t,a)+beta2*(1-lmda1((a)*da))*V1_3(t,a+1))*da/2;
        m3_3(t,a)=(beta1*(1-lmda2((a-1)*da))*V2_3(t,a)+beta1*(1-lmda2((a)*da))*V2_3(t,a+1))*da/2;
        m4_3(t,a)=(beta2*(1-lmda2((a-1)*da))*V2_3(t,a)+beta2*(1-lmda2((a)*da))*V2_3(t,a+1))*da/2;
        n1_3(t,a)=((lmda1((a-1)*da))*V1_3(t,a)+(lmda1((a)*da))*V1_3(t,a+1))*da/2;
        n2_3(t,a)=((lmda2((a-1)*da))*V2_3(t,a)+(lmda2((a)*da))*V2_3(t,a+1))*da/2;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        q4(t,a)=(p2_4*V1_4(t,a)+p2_4*V1_4(t,a+1))*da/2;
        m1_4(t,a)=(beta1*(1-lmda1((a-1)*da))*V1_4(t,a)+beta1*(1-lmda1((a)*da))*V1_4(t,a+1))*da/2;
        m2_4(t,a)=(beta2*(1-lmda1((a-1)*da))*V1_4(t,a)+beta2*(1-lmda1((a)*da))*V1_4(t,a+1))*da/2;
        m3_4(t,a)=(beta1*(1-lmda2((a-1)*da))*V2_4(t,a)+beta1*(1-lmda2((a)*da))*V2_4(t,a+1))*da/2;
        m4_4(t,a)=(beta2*(1-lmda2((a-1)*da))*V2_4(t,a)+beta2*(1-lmda2((a)*da))*V2_4(t,a+1))*da/2;
        n1_4(t,a)=((lmda1((a-1)*da))*V1_4(t,a)+(lmda1((a)*da))*V1_4(t,a+1))*da/2;
        n2_4(t,a)=((lmda2((a-1)*da))*V2_4(t,a)+(lmda2((a)*da))*V2_4(t,a+1))*da/2;
        
    end
       Q(t)=sum(q(t,:));
       M1(t)=sum(m1(t,:));
       M2(t)=sum(m2(t,:));
       M3(t)=sum(m3(t,:));
       M4(t)=sum(m4(t,:));
       N1(t)=sum(n1(t,:));
       N2(t)=sum(n2(t,:));
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       Q2(t)=sum(q2(t,:));
       M1_2(t)=sum(m1_2(t,:));
       M2_2(t)=sum(m2_2(t,:));
       M3_2(t)=sum(m3_2(t,:));
       M4_2(t)=sum(m4_2(t,:));
       N1_2(t)=sum(n1_2(t,:));
       N2_2(t)=sum(n2_2(t,:));
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       Q3(t)=sum(q3(t,:));
       M1_3(t)=sum(m1_3(t,:));
       M2_3(t)=sum(m2_3(t,:));
       M3_3(t)=sum(m3_3(t,:));
       M4_3(t)=sum(m4_3(t,:));
       N1_3(t)=sum(n1_3(t,:));
       N2_3(t)=sum(n2_3(t,:));
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       Q4(t)=sum(q4(t,:));
       M1_4(t)=sum(m1_4(t,:));
       M2_4(t)=sum(m2_4(t,:));
       M3_4(t)=sum(m3_4(t,:));
       M4_4(t)=sum(m4_4(t,:));
       N1_4(t)=sum(n1_4(t,:));
       N2_4(t)=sum(n2_4(t,:));
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       %V1(t+1,1)=p1(t*dt)*S(t);
       V1(t+1,1)=p1*S(t);
       V2(t+1,1)=Q(t)+dert*R(t);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       V1_2(t+1,1)=p1*S_2(t);
       V2_2(t+1,1)=Q_2(t)+dert*R_2(t);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       V1_3(t+1,1)=p1*S_3(t);
       V2_3(t+1,1)=Q_3(t)+dert*R_3(t);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       V1_4(t+1,1)=p1*S_4(t);
       V2_4(t+1,1)=Q_4(t)+dert*R_4(t);
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %S(t+1)=S(t)+(-p1(t*dt)*S(t)-beta1*S(t)*I1(t)/N(t)-beta2*S(t)*I2(t)/N(t))*dt;
    S(t+1)=S(t)+(-p1*S(t)-beta1*S(t)*I1(t)/N(t)-beta2*S(t)*I2(t)/N(t))*dt;
    E1(t+1)=E1(t)+(beta1*S(t)*I1(t)/N(t)+beta2*S(t)*I2(t)/N(t)-k*E1(t))*dt;
    E2(t+1)=E2(t)+(I1(t)*M1(t)/N(t)+I2(t)*M2(t)/N(t)-k*E2(t))*dt;
    E3(t+1)=E3(t)+(I1(t)*M3(t)/N(t)+I2(t)*M4(t)/N(t)-k*E3(t))*dt;
    I1(t+1)=I1(t)+((1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t)-gama1*I1(t))*dt;
    I2(t+1)=I2(t)+(rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t)-gama2*I2(t)-mui*I2(t))*dt;
    R(t+1)=R(t)+(gama1*I1(t)+gama2*I2(t)-dert*R(t))*dt;
    D(t+1)=mui*I2(t);
    N(t+1)=N(t)-D(t+1);
    I_V2(t+1)=k*E3(t);
    I_V1S(t+1)=k*E1(t)+k*E2(t);
    new_I1(t+1,1)=(1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t);
    new_I2(t+1,1)=rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t);
    new_I(t+1,1)=new_I1(t+1,1)+new_I2(t+1,1);
    L1(t)=N1(t)+N2(t)+E1(t)+E2(t)+E3(t)+I1(t)+I2(t)+R(t);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    S_2(t+1)=S_2(t)+(-p1*S_2(t)-beta1*S_2(t)*I1_2(t)/N_2(t)-beta2*S_2(t)*I2_2(t)/N_2(t))*dt;
    E1_2(t+1)=E1_2(t)+(beta1*S_2(t)*I1_2(t)/N_2(t)+beta2*S_2(t)*I2(t)/N_2(t)-k*E1_2(t))*dt;
    E2_2(t+1)=E2_2(t)+(I1_2(t)*M1_2(t)/N_2(t)+I2_2(t)*M2_2(t)/N_2(t)-k*E2_2(t))*dt;
    E3_2(t+1)=E3_2(t)+(I1_2(t)*M3_2(t)/N_2(t)+I2_2(t)*M4_2(t)/N_2(t)-k*E3_2(t))*dt;
    I1_2(t+1)=I1_2(t)+((1-rou1)*k*E1_2(t)+(1-rou2)*k*E2_2(t)+(1-rou3)*k*E3_2(t)-gama1*I1_2(t))*dt;
    I2_2(t+1)=I2_2(t)+(rou1*k*E1_2(t)+rou2*k*E2_2(t)+rou3*k*E3_2(t)-gama2*I2_2(t)-mui*I2_2(t))*dt;
    R_2(t+1)=R_2(t)+(gama1*I1_2(t)+gama2*I2_2(t)-dert*R_2(t))*dt;
    D_2(t+1)=mui*I2_2(t);
    N_2(t+1)=N_2(t)-D_2(t+1);
    L2(t)=N1_2(t)+N2_2(t)+E1_2(t)+E2_2(t)+E3_2(t)+I1_2(t)+I2_2(t)+R_2(t);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    S_3(t+1)=S_3(t)+(-p1*S_3(t)-beta1*S_3(t)*I1_3(t)/N_3(t)-beta2*S_3(t)*I2_3(t)/N_3(t))*dt;
    E1_3(t+1)=E1_3(t)+(beta1*S_3(t)*I1_3(t)/N_3(t)+beta2*S_3(t)*I2(t)/N_3(t)-k*E1_3(t))*dt;
    E2_3(t+1)=E2_3(t)+(I1_3(t)*M1_3(t)/N_3(t)+I2_3(t)*M2_3(t)/N_3(t)-k*E2_3(t))*dt;
    E3_3(t+1)=E3_3(t)+(I1_3(t)*M3_3(t)/N_3(t)+I2_3(t)*M4_3(t)/N_3(t)-k*E3_3(t))*dt;
    I1_3(t+1)=I1_3(t)+((1-rou1)*k*E1_3(t)+(1-rou2)*k*E2_3(t)+(1-rou3)*k*E3_3(t)-gama1*I1_3(t))*dt;
    I2_3(t+1)=I2_3(t)+(rou1*k*E1_3(t)+rou2*k*E2_3(t)+rou3*k*E3_3(t)-gama2*I2_3(t)-mui*I2_3(t))*dt;
    R_3(t+1)=R_3(t)+(gama1*I1_3(t)+gama2*I2_3(t)-dert*R_3(t))*dt;
    D_3(t+1)=mui*I2_3(t);
    N_3(t+1)=N_3(t)-D_3(t+1);
    L3(t)=N1_3(t)+N2_3(t)+E1_3(t)+E2_3(t)+E3_3(t)+I1_3(t)+I2_3(t)+R_3(t);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    S_4(t+1)=S_4(t)+(-p1*S_4(t)-beta1*S_4(t)*I1_4(t)/N_4(t)-beta2*S_4(t)*I2_3(t)/N_4(t))*dt;
    E1_4(t+1)=E1_4(t)+(beta1*S_4(t)*I1_4(t)/N_4(t)+beta2*S_4(t)*I2(t)/N_4(t)-k*E1_4(t))*dt;
    E2_4(t+1)=E2_4(t)+(I1_4(t)*M1_4(t)/N_4(t)+I2_4(t)*M2_4(t)/N_4(t)-k*E2_4(t))*dt;
    E3_4(t+1)=E3_4(t)+(I1_4(t)*M3_4(t)/N_4(t)+I2_4(t)*M4_4(t)/N_4(t)-k*E3_4(t))*dt;
    I1_4(t+1)=I1_4(t)+((1-rou1)*k*E1_4(t)+(1-rou2)*k*E2_4(t)+(1-rou3)*k*E3_4(t)-gama1*I1_4(t))*dt;
    I2_4(t+1)=I2_4(t)+(rou1*k*E1_4(t)+rou2*k*E2_4(t)+rou3*k*E3_4(t)-gama2*I2_4(t)-mui*I2_4(t))*dt;
    R_4(t+1)=R_4(t)+(gama1*I1_4(t)+gama2*I2_4(t)-dert*R_4(t))*dt;
    D_4(t+1)=mui*I2_4(t);
    N_4(t+1)=N_4(t)-D_4(t+1);
    L4(t)=N1_4(t)+N2_4(t)+E1_4(t)+E2_4(t)+E3_4(t)+I1_4(t)+I2_4(t)+R_4(t);

    for a=1:1:na-1
        %V1(t+1,a+1)=V1(t+1,a)+(-p2((a-1)*da)*V1(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1(t+1,a)*I1(t+1)/N(t+1)...
                              %-beta2*(1-lmda1((a-1)*da))*V1(t+1,a)*I2(t+1)/N(t+1))*da-da*(V1(t+1,a)-V1(t,a))/dt;
        V1(t+1,a+1)=V1(t+1,a)+(-p2_1*V1(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1(t+1,a)*I1(t+1)/N(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1(t+1,a)*I2(t+1)/N(t+1))*da-da*(V1(t+1,a)-V1(t,a))/dt;
                          
                          
        V2(t+1,a+1)=V2(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2(t+1,a)*I1(t+1)/N(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2(t+1,a)*I2(t+1)/N(t+1))*da-da*(V2(t+1,a)-V2(t,a))/dt;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        V1_2(t+1,a+1)=V1_2(t+1,a)+(-p2_2*V1_2(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1_2(t+1,a)*I1_2(t+1)/N_2(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1_2(t+1,a)*I2_2(t+1)/N_2(t+1))*da-da*(V1_2(t+1,a)-V1_2(t,a))/dt;
                          
                          
        V2_2(t+1,a+1)=V2_2(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2_2(t+1,a)*I1_2(t+1)/N_2(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2_2(t+1,a)*I2_2(t+1)/N_2(t+1))*da-da*(V2_2(t+1,a)-V2_2(t,a))/dt;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        V1_3(t+1,a+1)=V1_3(t+1,a)+(-p2_3*V1_3(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1_3(t+1,a)*I1_3(t+1)/N_3(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1_3(t+1,a)*I2_3(t+1)/N_3(t+1))*da-da*(V1_3(t+1,a)-V1_3(t,a))/dt;
                          
                          
        V2_3(t+1,a+1)=V2_3(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2_3(t+1,a)*I1_3(t+1)/N_3(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2_3(t+1,a)*I2_3(t+1)/N_3(t+1))*da-da*(V2_3(t+1,a)-V2_3(t,a))/dt;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        V1_4(t+1,a+1)=V1_4(t+1,a)+(-p2_4*V1_4(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1_4(t+1,a)*I1_4(t+1)/N_4(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1_4(t+1,a)*I2_4(t+1)/N_4(t+1))*da-da*(V1_4(t+1,a)-V1_4(t,a))/dt;
                          
                          
        V2_4(t+1,a+1)=V2_4(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2_4(t+1,a)*I1_4(t+1)/N_4(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2_4(t+1,a)*I2_4(t+1)/N_4(t+1))*da-da*(V2_4(t+1,a)-V2_4(t,a))/dt;
        
    
    end
    

end

t=1:1:nt;
a=1:1:na;
t1=t';
aa=(a-1)*da; tt=(t-1)*dt;

[TT, AA] = meshgrid(tt, aa);
% figure(1) 
% clf, 
%plot(t,I1,'b-.',t,I2,'r-.',t,I3,'g--','linewidth',3);

% plotyy(t1,[new_I1(t),new_I(t)],t1,[new_I2(t),D(t)]);
% xlabel('Time t (Date)','FontSize',16,'FontWeight','bold');
% ylabel('Number of people','FontSize',16,'FontWeight','bold');
% legend('Daily number of new mild infections','Total number of new daily infections');
% set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
% box on;
% grid on;

% figure
% yyaxis left
% plot(t,new_I1(t),'r-',t,new_I(t),'b-','linewidth',3);
% yyaxis right
% plot(t,new_I2(t),'g--',t,D(t),'m--','linewidth',3);
% legend('Daily number of new mild infections','Total number of new daily infections','Daily number of new severe infections','The number of new deaths per day');
% set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
% box on;
% grid on;
% figure(2)
% plot(t,new_I2(t),'g',t,D(t),'m','linewidth',3);
% xlabel('Time t (Date)','FontSize',16,'FontWeight','bold');
% ylabel('Number of people','FontSize',16,'FontWeight','bold');
% legend('Daily number of new severe infections','The number of new deaths per day');
% set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
% box on;
% grid on;

figure
plot(t,L1(t),t,L2(t),t,L3(t),t,L4(t),'linewidth',3);
xlabel('Time t (Date)','FontSize',16,'FontWeight','bold');
ylabel('L(t)','FontSize',16,'FontWeight','bold');
set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
box on;
grid on;

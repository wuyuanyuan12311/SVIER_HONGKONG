%������С���˷���Ŀ�꺯��
function d = LSmin(z)
%global h

beta1=z(1);
beta2=z(2);
gama1=z(3);
gama2=z(4);
rou1=z(5);
rou2=z(6);
rou3=z(7);
dert=z(8);
mui=z(9);
S0=z(10);
E10=z(11);
E20=z(12);
E30=z(13);
I10=z(14);
I20=z(15);
R0=z(16);
K=1/3;
%p2=0.028;
A=300;
%N=20000;%(���ڿ�����������������������NӦΪ����)
%S0=9269000;
V10=2254000;%����Ϊ��ʼʱ��������Ⱥ��δ�������缴V��1������=0��
V20=1036000;
% E20=0;
% E30=0;
T=300;%(����Ϊ��λ)
% dt=0.5;
% da=0.1;
dt=1;
da=0.01;
p=1;
nt=T/dt;
na=A/da;

S=zeros(nt,1);
E1=zeros(nt,1);
E2=zeros(nt,1);
E3=zeros(nt,1);
I1=zeros(nt,1);
I2=zeros(nt,1);
R=zeros(nt,1);
N=zeros(nt,1);
V1=zeros(nt,na);
V2=zeros(nt,na);

S(1)=S0;
E1(1)=E10;
E2(1)=E20;
E3(1)=E30;
I1(1)=I10;
I2(1)=I20;
R(1)=R0;
V1(1,1)=V10;
V2(1,1)=V20;

%%
for t=1:1:nt-1
    X1(t)=sum(V1(t,:));
    X2(t)=sum(V2(t,:));
    
%     new_I1(1,1)=I1(1);
%     new_I2(1,1)=I2(1);
%     new_I(1,1)=new_I1(1,1)+new_I2(1,1);
    
    N(1)=S(1)+X1(1)+X2(1)+E1(1)+E2(1)+E3(1)+I1(1)+I2(1)+R(1);%tʱ�̵�������
    
    for a=1:1:na-1
        q(t,a)=(p2((a-1)*da)*V1(t,a)+p2((a)*da)*V1(t,a+1))*da/2;
        m1(t,a)=(beta1*(1-lmda1((a-1)*da))*V1(t,a)+beta1*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m2(t,a)=(beta2*(1-lmda1((a-1)*da))*V1(t,a)+beta2*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m3(t,a)=(beta1*(1-lmda2((a-1)*da))*V2(t,a)+beta1*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
        m4(t,a)=(beta2*(1-lmda2((a-1)*da))*V2(t,a)+beta2*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
    end
       Q(t)=sum(q(t,:));
       M1(t)=sum(m1(t,:));
       M2(t)=sum(m2(t,:));
       M3(t)=sum(m3(t,:));
       M4(t)=sum(m4(t,:));
       
    
       V1(t+1,1)=p1(t*dt)*S(t);
       V2(t+1,1)=Q(t)+dert*R(t);
       
       
    S(t+1)=S(t)+(-p1(t*dt)*S(t)-beta1*S(t)*I1(t)/N(t)-beta2*S(t)*I2(t)/N(t))*dt;
    E1(t+1)=E1(t)+(beta1*S(t)*I1(t)/N(t)+beta2*S(t)*I2(t)/N(t)-k*E1(t))*dt;
    E2(t+1)=E2(t)+(I1(t)*M1(t)/N(t)+I2(t)*M2(t)/N(t)-k*E2(t))*dt;
    E3(t+1)=E3(t)+(I1(t)*M3(t)/N(t)+I2(t)*M4(t)/N(t)-k*E3(t))*dt;
    I1(t+1)=I1(t)+((1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t)-gama1*I1(t))*dt;
    I2(t+1)=I2(t)+(rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t)-gama2*I2(t)-mui*I2(t))*dt;
    R(t+1)=R(t)+(gama1*I1(t)+gama2*I2(t)-dert*R(t))*dt;
    N(t+1)=N(t)-mui*I2(t);
    new_I1(t+1,1)=(1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t);
%     new_I2(t+1,1)=rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t);
%     new_I(t+1,1)=new_I1(t+1,1)+new_I2(t+1,1);
    
   
    
    for a=1:1:na-1
        V1(t+1,a+1)=V1(t+1,a)+(-p2((a-1)*da)*V1(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1(t+1,a)*I1(t+1)/N(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1(t+1,a)*I2(t+1)/N(t+1))*da-da*(V1(t+1,a)-V1(t,a))/dt;
                          
        V2(t+1,a+1)=V2(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2(t+1,a)*I1(t+1)/N(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2(t+1,a)*I2(t+1)/N(t+1))*da-da*(V2(t+1,a)-V2(t,a))/dt;
    end
    

end

A_V1(:,1)=V1(:,1);
A_V2(:,1)=V2(:,1);
%A_I(:,1)=new_I(:,1);

% for t=1:1:nt
%     if mod(t,2)==1
%         AA_V1(p,1)=A_V1(t,1);
%         AA_V2(p,1)=A_V2(t,1);
%         AA_I(p,1)=A_I(t,1);
%         p=p+1;
%     end
   
%end


load data data
d=norm(new_I1(1:297)-data(:,1))+norm(I2(50:297)-data(50:297,2))+norm(D(1:297)-data(:,3))+norm(A_V1(1:297)-data(:,4))+norm(A_V2(1:297)-data(:,5));
%d=norm(AA_I(1:378)-data(:,3));
%d=norm(A_I(1:378)-data(:,3));
    
    


clc;
close all;
clear all;
beta1=0.6913; 
beta2=0.9947;
%beta2=1.2649;
gama1=0.3481;
gama2=0.1108;
dert=0.0307;
rou1=0.3271;
rou2=0.0913;
rou3=0.0572;
mui=0.0315;
k=1/3;%(假设潜伏期为两天)
% p1=0.00003;
% p2=0.000213;
% p1=0;
% p2=0.037;
%p2=0;                                                       
%p2=0.028;
A=800;%
%N=20000;%(由于考虑了因病死亡，所以总人数N应为变量)
dt=0.01;%步长
da=0.01;
%h=step; 
p=1;
T=800;%(以天为单位)
nt=T/dt;%
na=A/da;%
S=zeros(nt,1);
E1=zeros(nt,1);
E2=zeros(nt,1);
E3=zeros(nt,1);
I1=zeros(nt,1);
I2=zeros(nt,1);
I_V2=zeros(nt,1);
I_V1S=zeros(nt,1);
new_I1=zeros(nt,1);
new_I2=zeros(nt,1);
R=zeros(nt,1);
D=zeros(nt,1);
N=zeros(nt,1);
V1=zeros(nt,na);
V2=zeros(nt,na);
S0=283700000;
V10=1701000;
V20=597600000;
E10=5600;
E20=1114;
E30=302600;
R0=742000;
I10=212000;
I20=36000;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ;
new_I10=0;
new_I20=0;
%D0=0;
%e10=0;e20=0;
S(1)=S0;
E1(1)=E10;
E2(1)=E20;
E3(1)=E30;
I1(1)=I10;
I2(1)=I20;
new_I1(1)=new_I10;
new_I2(1)=new_I20;
new_I(1)=new_I10;
I_V2(1)=0;
R(1)=R0;
D(1)=D0;
V1(1,1)=V10;
V2(1,1)=V20;

for t=1:1:nt-1
    X1(t)=sum(V1(t,:));
    X2(t)=sum(V2(t,:));
    
%     new_I1(1,1)=I1(1);
%     new_I2(1,1)=I2(1);
%     new_I(1,1)=new_I1(1,1)+new_I2(1,1);
    
    N(1)=S(1)+X1(1)+X2(1)+E1(1)+E2(1)+E3(1)+I1(1)+I2(1)+R(1);
    
    for a=1:1:na-1
        q(t,a)=(p2((a-1)*da)*V1(t,a)+p2((a-1)*da)*V1(t,a+1))*da/2;
        %q(t,a)=(p2*V1(t,a)+p2*V1(t,a+1))*da/2;
        m1(t,a)=(beta1*(1-lmda1((a-1)*da))*V1(t,a)+beta1*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m2(t,a)=(beta2*(1-lmda1((a-1)*da))*V1(t,a)+beta2*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m3(t,a)=(beta1*(1-lmda2((a-1)*da))*V2(t,a)+beta1*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
        m4(t,a)=(beta2*(1-lmda2((a-1)*da))*V2(t,a)+beta2*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
        n1(t,a)=((lmda1((a-1)*da))*V1(t,a)+(lmda1((a)*da))*V1(t,a+1))*da/2;
        n2(t,a)=((lmda2((a-1)*da))*V2(t,a)+(lmda2((a)*da))*V2(t,a+1))*da/2;
    end
       Q(t)=sum(q(t,:));
       M1(t)=sum(m1(t,:));
       M2(t)=sum(m2(t,:));
       M3(t)=sum(m3(t,:));
       M4(t)=sum(m4(t,:));
       N1(t)=sum(n1(t,:));
       N2(t)=sum(n2(t,:));

       
   
       V1(t+1,1)=p1(t*dt)*S(t);
       %V1(t+1,1)=p1*S(t);
       V2(t+1,1)=Q(t)+dert*R(t);
       
       
    S(t+1)=S(t)+(-p1(t*dt)*S(t)-beta1*S(t)*I1(t)/N(t)-beta2*S(t)*I2(t)/N(t))*dt;
    %S(t+1)=S(t)+(-p1*S(t)-beta1*S(t)*I1(t)/N(t)-beta2*S(t)*I2(t)/N(t))*dt;
    E1(t+1)=E1(t)+(beta1*S(t)*I1(t)/N(t)+beta2*S(t)*I2(t)/N(t)-k*E1(t))*dt;
    E2(t+1)=E2(t)+(I1(t)*M1(t)/N(t)+I2(t)*M2(t)/N(t)-k*E2(t))*dt;
    E3(t+1)=E3(t)+(I1(t)*M3(t)/N(t)+I2(t)*M4(t)/N(t)-k*E3(t))*dt;
    I1(t+1)=I1(t)+((1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t)-gama1*I1(t))*dt;
    I2(t+1)=I2(t)+(rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t)-gama2*I2(t)-mui*I2(t))*dt;
    R(t+1)=R(t)+(gama1*I1(t)+gama2*I2(t)-dert*R(t))*dt;
    D(t+1)=mui*I2(t);
    N(t+1)=N(t)-D(t+1);
    I_V2(t+1)=k*E3(t);
    I_V1S(t+1)=k*E1(t)+k*E2(t);
    new_I1(t+1,1)=(1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t);
    new_I2(t+1,1)=rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t);
    new_I(t+1,1)=new_I1(t+1,1)+new_I2(t+1,1);
    L(t)=N1(t)+N2(t)+E1(t)+E2(t)+E3(t)+I1(t)+I2(t)+R(t);
    
    
    for a=1:1:na-1
        V1(t+1,a+1)=V1(t+1,a)+(-p2((a-1)*da)*V1(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1(t+1,a)*I1(t+1)/N(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1(t+1,a)*I2(t+1)/N(t+1))*da-da*(V1(t+1,a)-V1(t,a))/dt;
        %V1(t+1,a+1)=V1(t+1,a)+(-p2*V1(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1(t+1,a)*I1(t+1)/N(t+1)...
                              %-beta2*(1-lmda1((a-1)*da))*V1(t+1,a)*I2(t+1)/N(t+1))*da-da*(V1(t+1,a)-V1(t,a))/dt;
                          
                          
        V2(t+1,a+1)=V2(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2(t+1,a)*I1(t+1)/N(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2(t+1,a)*I2(t+1)/N(t+1))*da-da*(V2(t+1,a)-V2(t,a))/dt;
    end
    

end

new_case=new_I1(:,1);
I1_t=sum(new_I1(:,1));
% I11_T=sum(new_I1(1:360,1));
% I12_T=sum(new_I1(361:720,:));
I2_t=sum(new_I2(:,1));
% I21_T=sum(new_I2(1:360,1));
% I22_T=sum(new_I2(361:720,1));
I_t=sum(new_I(:,1));
% I11_t=sum(new_I(1:360,1));
% I22_t=sum(new_I(361:720,1));
D_t=sum(D(:,1));
% D1_t=sum(D(1:360,1));
% D2_t=sum(D(361:720,1));
% I_V2_1=sum(I_V2(1:360,1));   
t=1:1:nt;
a=1:1:na;
t1=t';
aa=(a-1)*da; tt=(t-1)*dt;

[TT, AA] = meshgrid(tt, aa);
% figure(1) 
% clf, 
%plot(t,I1,'b-.',t,I2,'r-.',t,I3,'g--','linewidth',3);

% plotyy(t1,[new_I1(t),new_I(t)],t1,[new_I2(t),D(t)]);
% xlabel('Time t (Date)','FontSize',16,'FontWeight','bold');
% ylabel('Number of people','FontSize',16,'FontWeight','bold');
% legend('Daily number of new mild infections','Total number of new daily infections');
% set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
% box on;
% grid on;

figure
yyaxis left
plot(t,new_I1(t),'r-',t,new_I(t),'b-','linewidth',3);
yyaxis right
plot(t,new_I2(t),'g--',t,D(t),'m--','linewidth',3);
legend('Daily number of new mild infections','Total number of new daily infections','Daily number of new severe infections','The number of new deaths per day');
set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
box on;
grid on;
% figure(2)
% plot(t,new_I2(t),'g',t,D(t),'m','linewidth',3);
% xlabel('Time t (Date)','FontSize',16,'FontWeight','bold');
% ylabel('Number of people','FontSize',16,'FontWeight','bold');
% legend('Daily number of new severe infections','The number of new deaths per day');
% set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
% box on;
% grid on;

% figure(3)
% plot(t,L(t),'linewidth',3);
% xlabel('Time t (Date)','FontSize',16,'FontWeight','bold');
% ylabel('L(t)','FontSize',16,'FontWeight','bold');
% set(gca,'linewidth',3,'FontSize',20,'FontWeight','bold')%坐标轴刻度变大加粗
% box on;
% grid on;

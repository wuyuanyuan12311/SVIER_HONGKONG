%�Ż�����
clear all
clc
% global h
% h=0.5;
data=xlsread('�������.xlsx'); 
%data1=zeros(4,length(data(:,1)));
save data 'data'
Time1=1:length(data(:,1));
Time=(Time1)';

   
lb=[0.1          0.2         0.1         0.01         0.05     0.01   0.01   0.001   0.001     1000000   10000     100       100      10       1       10  ];
ub=[ 1            2           1          0.95         0.5      0.2    0.1    0.05    0.08      5000000   50000     10000     5000     10000    1000    5000]; 


% lb=[0.3             0.5          0.01          0.01       0.011    10000      10        100      100       1   ];%Լ������������ֵ������
% ub=[1.5              2            1            0.8         1       900000    10000     10000     3000     500   ];  %Լ������������ֵ������
% % 
% options=optimoptions('ga','Display','final','Generations',500,'NonlinearConstraintAlgorithm','auglag');
% [z,fval] = ga(@(z) LSmin(z),10,[],[],[],[],lb,ub,[],options); %�����򣺣�zΪ�α�����fvalΪĿ�꺯��ֵ�����Ŵ��㷨��
% save z 'z'
% save fval 'fval'
% 

for i=1:100
    i
    z=rand(1,length(lb)).*(ub-lb)+lb;
    options=optimset('Display','final','MaxIter', 8000, 'MaxFunEvals',8000,'TolX',1e-6,'TolCon',1e-6,'Tolfun',1e-6);
%    options=optimset('Display','final','MaxIter', 8000, 'MaxFunEvals',2000);
    [z,fval] = fmincon(@LSmin,z0,[],[],[],[],lb,ub,[],options); 
    % options1=optimoptions('ga','Display','final','Generations',2000,'NonlinearConstraintAlgorithm','auglag');
    % [par1,fval]=ga(@(par1) ELPAWmin(par1,MOI,BI,T151,T152,T211,T212,year,month),28,[],[],[],[],lb,ub,@constraintfile,options1);%��������ʹ���Ŵ��㷨���в�������
    options1=optimoptions('ga','Display','final','Generations',2000,'NonlinearConstraintAlgorithm','auglag');
    [z,fval] = ga(@(z) LSmin(z),16,[],[],[],[],lb,ub,[],options); 

    zne(:,i)=z;
    fvalne(i)=fval;
end
save zne 'zne'
save fvalne 'fvalne' 
% par1= mean(zne,2);
z= zne(:,find(fvalne==min(fvalne)));
save z 'z'
% save fval 'fval'

 load z 'z'
%z=[0.0001        0.043      0.5428      0.0876       0.015      900000      100      10      3              ];%����ֵ�ĳ�ʼ

beta1=z(1);
beta2=z(2);
gama1=z(3);
gama2=z(4);
rou1=z(5);
rou2=z(6);
rou3=z(7);
dert=z(8);
mui=z(9);
S0=z(10);
E10=z(11);
E20=z(12);
E30=z(13);
I10=z(14);
I20=z(15);
R0=z(16);
K=1/3;
%p2=0.028;
A=300;
%N=20000;%(���ڿ�����������������������NӦΪ����)
%S0=9269000;%�����ʼʱ�̵����и������Ϊ�׸���
V10=2254000;
V20=1036000;
X0=[S0  V10  V20  E10  E20   E30  I10  I20   R0]; %��ʼ����%��ʼ����
T=300;%(����Ϊ��λ)
% dt=0.5;
% da=0.1;
dt=1;
da=0.01;
p=1;
nt=T/dt;
na=A/da;

S=zeros(nt,1);
E1=zeros(nt,1);
E2=zeros(nt,1);
E3=zeros(nt,1);
I1=zeros(nt,1);
I2=zeros(nt,1);
R=zeros(nt,1);
N=zeros(nt,1);
V1=zeros(nt,na);
V2=zeros(nt,na);

S(1)=S0;%��ֵ
E1(1)=E10;
E2(1)=E20;
E3(1)=E30;
I1(1)=I10;
I2(1)=I20;
R(1)=R0;
V1(1,1)=V10;
V2(1,1)=V20;
%%
for t=1:1:nt-1
    t
    X1(t)=sum(V1(t,:));
    X2(t)=sum(V2(t,:));
    
%     new_I1(1,1)=I1(1);
%     new_I2(1,1)=I2(1);
%     new_I(1,1)=new_I1(1,1)+new_I2(1,1);
    
    N(1)=S(1)+X1(1)+X2(1)+E1(1)+E2(1)+E3(1)+I1(1)+I2(1)+R(1);%tʱ�̵�������
    
    for a=1:1:na-1
        q(t,a)=(p2((a-1)*da)*V1(t,a)+p2((a)*da)*V1(t,a+1))*da/2;
        m1(t,a)=(beta1*(1-lmda1((a-1)*da))*V1(t,a)+beta1*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m2(t,a)=(beta2*(1-lmda1((a-1)*da))*V1(t,a)+beta2*(1-lmda1((a)*da))*V1(t,a+1))*da/2;
        m3(t,a)=(beta1*(1-lmda2((a-1)*da))*V2(t,a)+beta1*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
        m4(t,a)=(beta2*(1-lmda2((a-1)*da))*V2(t,a)+beta2*(1-lmda2((a)*da))*V2(t,a+1))*da/2;
    end
       Q(t)=sum(q(t,:));
       M1(t)=sum(m1(t,:));
       M2(t)=sum(m2(t,:));
       M3(t)=sum(m3(t,:));
       M4(t)=sum(m4(t,:));
       
      
       V1(t+1,1)=p1(t*dt)*S(t);
       V2(t+1,1)=Q(t)+dert*R(t);
       
       
    S(t+1)=S(t)+(-p1(t*dt)*S(t)-beta1*S(t)*I1(t)/N(t)-beta2*S(t)*I2(t)/N(t))*dt;
    E1(t+1)=E1(t)+(beta1*S(t)*I1(t)/N(t)+beta2*S(t)*I2(t)/N(t)-k*E1(t))*dt;
    E2(t+1)=E2(t)+(I1(t)*M1(t)/N(t)+I2(t)*M2(t)/N(t)-k*E2(t))*dt;
    E3(t+1)=E3(t)+(I1(t)*M3(t)/N(t)+I2(t)*M4(t)/N(t)-k*E3(t))*dt;
    I1(t+1)=I1(t)+((1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t)-gama1*I1(t))*dt;
    I2(t+1)=I2(t)+(rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t)-gama2*I2(t)-mui*I2(t))*dt;
    R(t+1)=R(t)+(gama1*I1(t)+gama2*I2(t)-dert*R(t))*dt;
    N(t+1)=N(t)-mui*I2(t);
    new_I1(t+1,1)=(1-rou1)*k*E1(t)+(1-rou2)*k*E2(t)+(1-rou3)*k*E3(t);
%     new_I2(t+1,1)=rou1*k*E1(t)+rou2*k*E2(t)+rou3*k*E3(t);
%     new_I(t+1,1)=new_I1(t+1,1)+new_I2(t+1,1);
    
    
    
    for a=1:1:na-1
        V1(t+1,a+1)=V1(t+1,a)+(-p2((a-1)*da)*V1(t+1,a)-beta1*(1-lmda1((a-1)*da))*V1(t+1,a)*I1(t+1)/N(t+1)...
                              -beta2*(1-lmda1((a-1)*da))*V1(t+1,a)*I2(t+1)/N(t+1))*da-da*(V1(t+1,a)-V1(t,a))/dt;
                          
        V2(t+1,a+1)=V2(t+1,a)+(-beta1*(1-lmda2((a-1)*da))*V2(t+1,a)*I1(t+1)/N(t+1)...
                            -beta2*(1-lmda2((a-1)*da))*V2(t+1,a)*I2(t+1)/N(t+1))*da-da*(V2(t+1,a)-V2(t,a))/dt;
    end
    

end

A_V1(:,1)=V1(:,1);
A_V2(:,1)=V2(:,1);
%A_I(:,1)=new_I(:,1);

% for t=1:1:nt
%     if mod(t,2)==1
%         AA_V1(p,1)=A_V1(t,1);
%         AA_V2(p,1)=A_V2(t,1);
%         AA_I(p,1)=A_I(t,1);
%         p=p+1;
%     end
%     
% end



Tend1=1:length(new_I1(:,1));
Tend=Tend1';
figure(1)
plot(Tend,new_I1,'k','LineWidth',1.5)
hold on
plot(Time,data(:,1),'ro','MarkerSize',4)
xlabel('t')
ylabel('Daily number of new confirmed cases')


figure(2)
plot(Tend,I2,'k','LineWidth',1.5)
hold on
plot(Time,data(:,2),'ro','MarkerSize',4)
xlabel('t')
ylabel('Current number of hospitalized persons')


figure(3)
plot(Tend,D,'k','LineWidth',1.5)
hold on
plot(Time,data(:,3) ,'ro','MarkerSize',4)
xlabel('t')
ylabel('The number of new deaths per day')

figure(4)
plot(Tend,A_V1,'k','LineWidth',1.5)
hold on
plot(Time,data(:,4) ,'ro','MarkerSize',4)
xlabel('t')
ylabel('Number of people receiving basic vaccines daily')

figure(5)
plot(Tend,A_V2,'k','LineWidth',1.5)
hold on
plot(Time,data(:,5) ,'ro','MarkerSize',4)
xlabel('t')
ylabel('Number of people receiving booster vaccines daily')













